﻿namespace WindowsFormsApplication1
{
    partial class Holiday
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.btnAddHoliday = new System.Windows.Forms.Button();
            this.lblAddHoliday = new System.Windows.Forms.Label();
            this.lblHolidayDate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = System.Drawing.Color.Transparent;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.Color.White;
            this.lblDate.Location = new System.Drawing.Point(31, 53);
            this.lblDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(42, 17);
            this.lblDate.TabIndex = 0;
            this.lblDate.Text = "Date:";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(31, 84);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(39, 17);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Title:";
            // 
            // txtTitle
            // 
            this.txtTitle.BackColor = System.Drawing.Color.Black;
            this.txtTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitle.ForeColor = System.Drawing.Color.White;
            this.txtTitle.Location = new System.Drawing.Point(80, 84);
            this.txtTitle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(295, 23);
            this.txtTitle.TabIndex = 4;
            // 
            // btnAddHoliday
            // 
            this.btnAddHoliday.Location = new System.Drawing.Point(281, 127);
            this.btnAddHoliday.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAddHoliday.Name = "btnAddHoliday";
            this.btnAddHoliday.Size = new System.Drawing.Size(82, 32);
            this.btnAddHoliday.TabIndex = 6;
            this.btnAddHoliday.Text = "Add Holiday!";
            this.btnAddHoliday.UseVisualStyleBackColor = true;
            this.btnAddHoliday.Click += new System.EventHandler(this.btnAddHoliday_Click);
            // 
            // lblAddHoliday
            // 
            this.lblAddHoliday.AutoSize = true;
            this.lblAddHoliday.BackColor = System.Drawing.Color.Transparent;
            this.lblAddHoliday.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddHoliday.ForeColor = System.Drawing.Color.Transparent;
            this.lblAddHoliday.Location = new System.Drawing.Point(156, 20);
            this.lblAddHoliday.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddHoliday.Name = "lblAddHoliday";
            this.lblAddHoliday.Size = new System.Drawing.Size(118, 17);
            this.lblAddHoliday.TabIndex = 7;
            this.lblAddHoliday.Text = "Add Your Holiday";
            
            // 
            // lblHolidayDate
            // 
            this.lblHolidayDate.AutoSize = true;
            this.lblHolidayDate.BackColor = System.Drawing.Color.Transparent;
            this.lblHolidayDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHolidayDate.ForeColor = System.Drawing.Color.White;
            this.lblHolidayDate.Location = new System.Drawing.Point(82, 53);
            this.lblHolidayDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHolidayDate.Name = "lblHolidayDate";
            this.lblHolidayDate.Size = new System.Drawing.Size(46, 17);
            this.lblHolidayDate.TabIndex = 8;
            this.lblHolidayDate.Text = "label1";
            // 
            // Holiday
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(401, 175);
            this.Controls.Add(this.lblHolidayDate);
            this.Controls.Add(this.lblAddHoliday);
            this.Controls.Add(this.btnAddHoliday);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblDate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Holiday";
            this.Text = "Holiday";
            this.Load += new System.EventHandler(this.Holiday_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Button btnAddHoliday;
        private System.Windows.Forms.Label lblAddHoliday;
        private System.Windows.Forms.Label lblHolidayDate;
    }
}