﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class calendar : Form
    {
        public int month, year;
        bool AddEventbutton_Clicked = false;
        bool check;
        public Dictionary<string, string> eventLog = new Dictionary<string, string>()
        {
         {"01/08/2022","Birthday"}
        };
        

        public calendar()
        {
            InitializeComponent();
            timer.Start();
            
            
        }

       
        private void calendar_Load(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            month = now.Month;
            year = now.Year;

            calendarDisplay(year, month);
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToLongTimeString();
            lblDate.Text = DateTime.Now.ToLongDateString();
            
        }


         private void btnNext_Click(object sender, EventArgs e)
         {
             datespanel.Controls.Clear();
             month = month + 1;

             if(month == 12)
             {
                 year++;
                 month = 1;
             }

             calendarDisplay(year, month);


         }

         private void btnPrevious_Click(object sender, EventArgs e)
         {
             datespanel.Controls.Clear();
             month--;

             if (month == 0)
             {
                 year--;
                 month = 12;
             }

             calendarDisplay(year, month);

            
         }

        private void calendarDisplay (int year, int month )
         {
             string CurrentMonth = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
             lblMonth.Text = CurrentMonth + " " + year;

             DateTime startofthemonth = new DateTime(year, month, 1);            //First Day of the present month
             int days = DateTime.DaysInMonth(year, month);       // no of days in a month 
             int dayoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d")) + 1;

             int previousmonth = month - 1;
             if (previousmonth == 0)
                {
                     previousmonth = 12;
                }
             int noOfDaysLastMonth = DateTime.DaysInMonth(year, previousmonth);
             int temp = dayoftheweek;

             for (int i = 1; i < dayoftheweek; i++)
             {

                 UserControlDays ucdateslastmonth = new UserControlDays();
                 ucdateslastmonth.days((noOfDaysLastMonth - (temp-2)), month, year,true);
                 datespanel.Controls.Add(ucdateslastmonth);
                 temp--;
             }

             for (int i = 1; i <= days; i++)
             {

                 UserControlDays ucdates = new UserControlDays();
                 ucdates.days(i, month, year, false);
                 datespanel.Controls.Add(ucdates);
                 if (ucdates.AddEventbtnClicked)
                 {
                     eventLog.Add(ucdates.date1, ucdates.title);
                 }
                 check = ucdates.datesBtnClicked;
                
             }

         }

        private void btnEvent_Click(object sender, EventArgs e)
        {
            
            if (txtEvent.TextLength == 0)
            {
                AddEventbutton_Clicked = false;
                MessageBox.Show("Add event!");
            }
            else if (check)
            {
                AddEventbutton_Clicked = true;
                MessageBox.Show("Event Added");
            }
            
        }

      

        
        
    }
}
