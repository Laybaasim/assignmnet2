﻿namespace WindowsFormsApplication1
{
    partial class calendar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.lblSu = new System.Windows.Forms.Label();
            this.lblMo = new System.Windows.Forms.Label();
            this.lblSa = new System.Windows.Forms.Label();
            this.lblFr = new System.Windows.Forms.Label();
            this.lblTh = new System.Windows.Forms.Label();
            this.lblWe = new System.Windows.Forms.Label();
            this.lblTu = new System.Windows.Forms.Label();
            this.datespanel = new System.Windows.Forms.FlowLayoutPanel();
            this.lblMonth = new System.Windows.Forms.Label();
            this.txtEvent = new System.Windows.Forms.TextBox();
            this.lblEventDate = new System.Windows.Forms.Label();
            this.btnEvent = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTime.Location = new System.Drawing.Point(22, 18);
            this.lblTime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(69, 35);
            this.lblTime.TabIndex = 0;
            this.lblTime.Text = "Time";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.lblDate.Location = new System.Drawing.Point(27, 50);
            this.lblDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(30, 17);
            this.lblDate.TabIndex = 1;
            this.lblDate.Text = "Date";
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.Transparent;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNext.ForeColor = System.Drawing.Color.White;
            this.btnNext.Location = new System.Drawing.Point(365, 81);
            this.btnNext.Margin = new System.Windows.Forms.Padding(2);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(33, 20);
            this.btnNext.TabIndex = 3;
            this.btnNext.Text = "⌄";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.BackColor = System.Drawing.Color.Transparent;
            this.btnPrevious.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPrevious.ForeColor = System.Drawing.Color.White;
            this.btnPrevious.Location = new System.Drawing.Point(320, 81);
            this.btnPrevious.Margin = new System.Windows.Forms.Padding(2);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(33, 20);
            this.btnPrevious.TabIndex = 4;
            this.btnPrevious.Text = "⌃";
            this.btnPrevious.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPrevious.UseVisualStyleBackColor = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // lblSu
            // 
            this.lblSu.AutoSize = true;
            this.lblSu.BackColor = System.Drawing.Color.Transparent;
            this.lblSu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSu.ForeColor = System.Drawing.Color.White;
            this.lblSu.Location = new System.Drawing.Point(27, 122);
            this.lblSu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSu.Name = "lblSu";
            this.lblSu.Size = new System.Drawing.Size(25, 17);
            this.lblSu.TabIndex = 6;
            this.lblSu.Text = "Su";
            // 
            // lblMo
            // 
            this.lblMo.AutoSize = true;
            this.lblMo.BackColor = System.Drawing.Color.Transparent;
            this.lblMo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMo.ForeColor = System.Drawing.Color.White;
            this.lblMo.Location = new System.Drawing.Point(78, 122);
            this.lblMo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMo.Name = "lblMo";
            this.lblMo.Size = new System.Drawing.Size(27, 17);
            this.lblMo.TabIndex = 7;
            this.lblMo.Text = "Mo";
            // 
            // lblSa
            // 
            this.lblSa.AutoSize = true;
            this.lblSa.BackColor = System.Drawing.Color.Transparent;
            this.lblSa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSa.ForeColor = System.Drawing.Color.White;
            this.lblSa.Location = new System.Drawing.Point(357, 122);
            this.lblSa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSa.Name = "lblSa";
            this.lblSa.Size = new System.Drawing.Size(25, 17);
            this.lblSa.TabIndex = 8;
            this.lblSa.Text = "Sa";
            // 
            // lblFr
            // 
            this.lblFr.AutoSize = true;
            this.lblFr.BackColor = System.Drawing.Color.Transparent;
            this.lblFr.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFr.ForeColor = System.Drawing.Color.White;
            this.lblFr.Location = new System.Drawing.Point(300, 122);
            this.lblFr.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFr.Name = "lblFr";
            this.lblFr.Size = new System.Drawing.Size(21, 17);
            this.lblFr.TabIndex = 9;
            this.lblFr.Text = "Fr";
            // 
            // lblTh
            // 
            this.lblTh.AutoSize = true;
            this.lblTh.BackColor = System.Drawing.Color.Transparent;
            this.lblTh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTh.ForeColor = System.Drawing.Color.White;
            this.lblTh.Location = new System.Drawing.Point(244, 122);
            this.lblTh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTh.Name = "lblTh";
            this.lblTh.Size = new System.Drawing.Size(25, 17);
            this.lblTh.TabIndex = 10;
            this.lblTh.Text = "Th";
            // 
            // lblWe
            // 
            this.lblWe.AutoSize = true;
            this.lblWe.BackColor = System.Drawing.Color.Transparent;
            this.lblWe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWe.ForeColor = System.Drawing.Color.White;
            this.lblWe.Location = new System.Drawing.Point(188, 122);
            this.lblWe.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWe.Name = "lblWe";
            this.lblWe.Size = new System.Drawing.Size(29, 17);
            this.lblWe.TabIndex = 11;
            this.lblWe.Text = "We";
            // 
            // lblTu
            // 
            this.lblTu.AutoSize = true;
            this.lblTu.BackColor = System.Drawing.Color.Transparent;
            this.lblTu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTu.ForeColor = System.Drawing.Color.White;
            this.lblTu.Location = new System.Drawing.Point(134, 122);
            this.lblTu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTu.Name = "lblTu";
            this.lblTu.Size = new System.Drawing.Size(25, 17);
            this.lblTu.TabIndex = 12;
            this.lblTu.Text = "Tu";
            // 
            // datespanel
            // 
            this.datespanel.BackColor = System.Drawing.Color.DimGray;
            this.datespanel.Location = new System.Drawing.Point(15, 154);
            this.datespanel.Margin = new System.Windows.Forms.Padding(2);
            this.datespanel.Name = "datespanel";
            this.datespanel.Size = new System.Drawing.Size(392, 288);
            this.datespanel.TabIndex = 13;
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.BackColor = System.Drawing.Color.Transparent;
            this.lblMonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonth.ForeColor = System.Drawing.Color.White;
            this.lblMonth.Location = new System.Drawing.Point(26, 88);
            this.lblMonth.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(77, 17);
            this.lblMonth.TabIndex = 14;
            this.lblMonth.Text = "MonthYear";
            // 
            // txtEvent
            // 
            this.txtEvent.Location = new System.Drawing.Point(15, 481);
            this.txtEvent.Name = "txtEvent";
            this.txtEvent.Size = new System.Drawing.Size(270, 20);
            this.txtEvent.TabIndex = 15;
            // 
            // lblEventDate
            // 
            this.lblEventDate.AutoSize = true;
            this.lblEventDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEventDate.ForeColor = System.Drawing.Color.White;
            this.lblEventDate.Location = new System.Drawing.Point(17, 455);
            this.lblEventDate.Name = "lblEventDate";
            this.lblEventDate.Size = new System.Drawing.Size(77, 16);
            this.lblEventDate.TabIndex = 16;
            this.lblEventDate.Text = "Event Date ";
            // 
            // btnEvent
            // 
            this.btnEvent.Location = new System.Drawing.Point(323, 479);
            this.btnEvent.Name = "btnEvent";
            this.btnEvent.Size = new System.Drawing.Size(75, 23);
            this.btnEvent.TabIndex = 17;
            this.btnEvent.Text = "Add Event";
            this.btnEvent.UseVisualStyleBackColor = true;
            this.btnEvent.Click += new System.EventHandler(this.btnEvent_Click);
            // 
            // calendar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(428, 538);
            this.Controls.Add(this.btnEvent);
            this.Controls.Add(this.lblEventDate);
            this.Controls.Add(this.txtEvent);
            this.Controls.Add(this.lblMonth);
            this.Controls.Add(this.datespanel);
            this.Controls.Add(this.lblTu);
            this.Controls.Add(this.lblWe);
            this.Controls.Add(this.lblTh);
            this.Controls.Add(this.lblFr);
            this.Controls.Add(this.lblSa);
            this.Controls.Add(this.lblMo);
            this.Controls.Add(this.lblSu);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblTime);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "calendar";
            this.Text = "calendar";
            this.Load += new System.EventHandler(this.calendar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Label lblSu;
        private System.Windows.Forms.Label lblMo;
        private System.Windows.Forms.Label lblSa;
        private System.Windows.Forms.Label lblFr;
        private System.Windows.Forms.Label lblTh;
        private System.Windows.Forms.Label lblWe;
        private System.Windows.Forms.Label lblTu;
        private System.Windows.Forms.FlowLayoutPanel datespanel;
        private System.Windows.Forms.Label lblMonth;
        public System.Windows.Forms.TextBox txtEvent;
        public System.Windows.Forms.Label lblEventDate;
        private System.Windows.Forms.Button btnEvent;
    }
}

