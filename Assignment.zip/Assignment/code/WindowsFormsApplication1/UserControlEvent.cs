﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class UserControlEvent : UserControl
    {
        public UserControlEvent()
        {
            InitializeComponent();
        }

        private void btnEvent_Click(object sender, EventArgs e)
        {

        }

        public void days(int date, int month, int year)
        {
            string dateToday = DateTime.Now.ToString("dd");
            int presentMonth = DateTime.Now.Month;
            int presentYear = DateTime.Now.Year;
            btnEvent.Text = Convert.ToString(date);

            
           // date1 = btnEvent.Text + "/" + Convert.ToString(month) + "/" + Convert.ToString(year);

        }
    }
}
