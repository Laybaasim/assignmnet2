﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class Holiday : Form
    {
        public string date;
        public bool check = false;
        public string title; 

        public Holiday()
       
        {
            InitializeComponent();
        }

       

        private void btnAddHoliday_Click(object sender, EventArgs e)
        {
            if(txtTitle.TextLength == 0)
            {
                MessageBox.Show("Please Add Event!");
            }
            else
            {
                MessageBox.Show("Event Added");
                check = true;
                title = txtTitle.Text;
                this.Close();
            }
            
        }

        private void Holiday_Load(object sender, EventArgs e)
        {
            lblHolidayDate.Text = date;

        }

       

        
       
    }
}
