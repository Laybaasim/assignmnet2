﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;


namespace WindowsFormsApplication1
{
    public partial class UserControlDays : UserControl
    {
        public string date1;
        public string title;
        public bool AddEventbtnClicked;
        public bool datesBtnClicked = false; 

        public UserControlDays()
        {
            InitializeComponent();
           
            
        }


        private void UserControlDays_Load(object sender, EventArgs e)
        {
            
           


        }
        public void days (int date, int month, int year, bool checkIfPrevMonth)
        {
            string dateToday = DateTime.Now.ToString("dd");
            int presentMonth = DateTime.Now.Month;
            int presentYear = DateTime.Now.Year;
            btnDate.Text = Convert.ToString(date);
           

            if (checkIfPrevMonth == true)
            {
                btnDate.ForeColor = Color.Black;
                btnDate.Enabled = false;
            }

            if((month== presentMonth)&(year==presentYear))
            {
                if (btnDate.Text.Length < 2)
                {
                    if (("0" + btnDate.Text) == dateToday)
                    {
                        btnDate.BackColor = Color.Blue;
                    }
                }
                else if (btnDate.Text == dateToday)
                {
                    btnDate.BackColor = Color.Blue;
                }
            }

            if (btnDate.Text.Length < 2)
            {
                date1 ="0"+ btnDate.Text + "/" + Convert.ToString(month) + "/" + Convert.ToString(year);
            }
            else
                date1 = btnDate.Text + "/" + Convert.ToString(month) + "/" + Convert.ToString(year);
            
           
           
        }

        public void btnDate_Click(object sender, EventArgs e)
        {
            Holiday AddHoliday = new Holiday();
            AddHoliday.date = date1;
            AddHoliday.ShowDialog();
            AddEventbtnClicked = AddHoliday.check;

            if (AddEventbtnClicked)
            {
                title = AddHoliday.title;
                btnDate.BackColor = Color.Red;
                
                AddEventbtnClicked = false;
            }

            
           
            
           
        }

       
    }
}
