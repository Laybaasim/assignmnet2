﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace minesweeper2
{
    public partial class Game : Form
    {
        private int[,] board;
        private Button[,] buttons;
        int height;
        int width;
        string gameLevel;

        public Game(string Level)
        {
            InitializeComponent();
            gameLevel = Level;
        }

        private void init(int rows, int cols, int bomb)
        {
            board = new int[rows, cols];
            buttons = new Button[rows, cols];

            if (bomb > 0.8 * rows * cols)
                bomb = (int)(0.8 * rows * cols);
            Random rand = new Random();



            while (bomb > 0)
            {
                int x = rand.Next(rows);
                int y = rand.Next(cols);


                if (board[x, y] == -1) continue;
                board[x, y] = -1;


                for (int dx = -1; dx <= 1; dx++)
                {
                    for (int dy = -1; dy <= 1; dy++)
                    {
                        if (x + dx < 0) continue;
                        if (y + dy < 0) continue;
                        if (x + dx >= rows) continue;
                        if (y + dy >= cols) continue;
                        if (board[x + dx, y + dy] != -1)
                        {

                            board[x + dx, y + dy]++;
                        }
                    }
                }
                bomb--;
            }

        }

        private void mineSweeper() 
        {
            if (gameLevel == "Beginner")
            {
                init(10, 10, 10);
                height = 40;
                width = 40;
            }
            else if (gameLevel == "Expert")
            {
                init(16, 16, 40);
                height = 20;
                width = 20;
            }

            for (int row = 0; row < board.GetLength(0); row++)
            {
                for (int col = 0; col < board.GetLength(1); col++)
                {
                    Button tile = new Button();
                    buttons[col, row] = tile;
                    Controls.Add(tile);
                    tile.Height = height;
                    tile.Width = width;
                    tile.Left = height * col;
                    tile.Top = width * row;
                    tile.Text = "";
                    tile.ForeColor = Color.Black;
                    //tile.BackColor = Color.Gray;
                    tile.Click += tile_Click;
                }
            }
        }
        private void Game_Load(object sender, EventArgs e)
        {
            mineSweeper();
            
        }

        private void bombDetected() 
        {
            MessageBox.Show("You Lost!");
            this.Close();
            Form1 newGame = new Form1();
            newGame.Show();

        }

        void tile_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            int x = btn.Left / width;
            int y = btn.Top / height;

            if (board[x, y] == -1)
            {
                buttons[x, y].Enabled = false;
                btn.Text = "\U0001F4A3";
                btn.BackColor = System.Drawing.ColorTranslator.FromHtml("#D19C1D");
                bombDetected();
                
            }
            else
            {
                if (board[x, y] == 0)
                {
                    btn.Text = "";
                    revealTile(x, y);
                }
                else
                {
                    btn.Text = "" + board[x, y];
                }
            }
            btn.Enabled = false;
        }



        private void revealTile(int x, int y)
        {
            Stack<Point> stack = new Stack<Point>();
            stack.Push(new Point(x, y)); //Push value in the stack

            while (stack.Count > 0)
            {
                Point p = stack.Pop();
                if (p.X < 0 || p.Y < 0) continue;
                if (p.X >= board.GetLength(0) || p.Y >= board.GetLength(1)) continue;
                if (!buttons[p.X, p.Y].Enabled) continue;

                buttons[p.X, p.Y].Enabled = false;


                if (board[p.X, p.Y] != 0)
                {
                    buttons[p.X, p.Y].Text = "" + board[p.X, p.Y];

                }

                if (board[p.X, p.Y] != 0) continue;

                stack.Push(new Point((p.X + 1), p.Y));
                stack.Push(new Point((p.X - 1), p.Y));
                stack.Push(new Point(p.X, (p.Y - 1)));
                stack.Push(new Point(p.X, (p.Y + 1)));

            }



        }

        private void btnReset_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form1 newGame = new Form1();
            newGame.Show();
        }

 


    }
}

